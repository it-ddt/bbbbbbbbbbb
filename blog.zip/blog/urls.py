from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.urls import reverse_lazy



app_name = "blog"
urlpatterns = [
    path("", views.PostListView.as_view(), name="index"),
    path("add", views.PostCreateView.as_view(), name="add_post"),
    path("read/<int:pk>", views.PostDetailView.as_view(), name="read_post"),
    path("delete/<int:pk>", views.PostDeleteView.as_view(), name="delete_post"),
    path("edit/<int:pk>", views.PostUpdateView.as_view(), name="edit_post"),
    path("accounts/login", auth_views.LoginView.as_view(), name="login"),
    path("accounts/logout", auth_views.LogoutView.as_view(next_page=reverse_lazy("blog:index")), name="logout"),
    path("accounts/register", views.register, name="register"),
    path("category/all", views.CategoryListView.as_view(), name="show_all_categories"),
    path("category/<int:pk>", views.CategoryDetailView.as_view(), name="show_category"),
]
