from django.shortcuts import render
from django.contrib.auth import authenticate, login
from django.http import HttpResponseRedirect
from django.urls import reverse, reverse_lazy
from django.views.generic import ListView, CreateView, DeleteView, UpdateView, DetailView
from .models import Post, Category
from .forms import CustomUserCreationForm


def register(request):
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        if form.is_valid:
            form.save()
            new_user = authenticate(
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password']
            )
            login(request, new_user)
            return HttpResponseRedirect(reverse("blog:index"))
    else:
        form = CustomUserCreationForm()
        data = {"form": form}
        return render(request, "registration/register.html", data)


class PostDetailView(DetailView):
    model = Post


class PostListView(ListView):
    model = Post


class PostCreateView(CreateView):
    model = Post
    fields = "__all__"
    success_url = reverse_lazy("blog:index")


class PostDeleteView(DeleteView):
    model = Post
    success_url = reverse_lazy("blog:index")


class PostUpdateView(UpdateView):
    model = Post
    fields = "__all__"
    success_url = reverse_lazy("blog:index")
    template_name_suffix = '_update_form'


class CategoryListView(ListView):
    model = Category
    template_name = "category_list"


class CategoryDetailView(DetailView):
    model = Category
